﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_431_Assignment_2.Commands
{
    class Test : Command
    {

        public Test()
        {
            this.Name = "Test";
        }

        public override void Execute(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
